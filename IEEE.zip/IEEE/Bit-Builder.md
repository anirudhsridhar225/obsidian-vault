## Team members:
- PushkarSinghania13
- Punyamittal
- GarvBansal216
- veebbruh

## Remarks:
- proper html site made and code displayed
- they've somewhat achieved the problem statement but they've just hardcoded doc links and yt videos
- no use of ai or the such to generate learning content

## Rating:
5.5/10 (would've been higher if learning content was original)