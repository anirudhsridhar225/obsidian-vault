these people have somehow uploaded their code on google drive for version control instead of github i truly have no words

# Team Capslock
## Remarks:
- proper nextjs project
- proper routes, good code
- is only implemented in local ip4 LAN, but cool idea nonetheless

## Rating:
7/10 (everything seems to work with stable connection)