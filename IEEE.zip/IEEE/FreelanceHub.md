## Team members:
- Anirudh D
- Jezer
- Jineshwar
- William

## Remarks:
- figma file made for design and they've submitted that as well (very rudimentary design im not rating it)
- they haven't finished coding a live app
- passkey based auth, where the passkey is used to verify the user, and they've tokenized the users' abilities and used BERT to generate a similarity score for matching
- all transactions are smart contracts

## Rating:
5/10 they haven't really used blockchain for matching which was the original problem statement