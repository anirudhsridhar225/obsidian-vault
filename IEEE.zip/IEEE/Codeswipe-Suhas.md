used same name as idea so first team member name is the id

## Team members:
- Suhas Koheda
- Kalla Sai Suhas
- Kommana Sriram

## Remarks:
- haven't fully finished the app but they have maybe 50-60% implementation
- they also have an in-progress kotlin app for the same

## Rating:
5.5/10