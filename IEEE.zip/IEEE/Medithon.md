## Team Members (only gh ids):
- AvinashKumar21105
- Sachin1395
- Kamalesh-Kumar-K
- gurhoshiaa

## Remarks:
- properly implemented auth and encryption of medical records
- has well thought out planned features
- many things are yet to be implemented

## Rating:
4.5/10 (planning is good) (keys out in the open dawg)