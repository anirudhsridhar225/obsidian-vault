# Team members:
- GoutamAdityan
- Dhirajj77
- DerrickRajkumar
- Vishwa-Thangapandiyan

## Remarks:
- framer and gamma website deployed, mostly no-code tools used
- decent solution 
- no code displayed so im assuming not coded at all

## Rating:
6.5/10 (good idea would've scored higher if there were a working solution)