## Team members:
- Abinandhan.R  
- Vinay B  
- Ganesh A  
- Parvesh SM

## Remarks:
- have a somewhat working prototype
- no particular ai use for generating content or tests, they've hardcoded everything for the time being

## Rating:
4.5/10
