No original project name so yeah

## Remarks:
- hasn't shown his code anywhere, or provided a github
- rudimentary wix site as live deployment
- okay ish idea, no encryption or security measures provided

## Rating: 
4.5/10