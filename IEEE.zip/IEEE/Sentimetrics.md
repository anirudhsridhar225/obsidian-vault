## Team members:
- Vijay Aravindh S. (23BAI1160)  
- Adithiyaa D. (23BAI1038)  
- T. Lakshhmi Narayanan (23BAI1048)  
- Rishika Cilji Saravanan (23BAI1328)

## Remarks:
- good ish code, well thought out idea
- cross-language support is appreciated
- proper deployment instructions and styled (somewhat) site

## Rating:
7.5/10