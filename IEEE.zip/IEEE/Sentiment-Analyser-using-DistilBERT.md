## Team members:
- jeffr49
- sadhan-312006
- hariniKK863
- krithi201005

## Remarks:
- seems to be a working model, they've posted their final training scores as well
- good ish code
- interesting html page names (no effect on rating it's just silly)

## Rating:
6/10