imdb for music

## Team Members:
- Chirag
- Catherine
- Shashwath
- Satwik (i think?) swik03 github
## Remarks:
- proper vercel deployment
- user login and personalized homepage included
- good coverage of the tmud PS

## Ratings:
8.5/10