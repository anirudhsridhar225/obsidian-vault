[[MoonNight]] - 8
[[Medithon]] - 4.5 ((keys))
[[Sentimetrics]] - 7.5
[[The Medical Canopy]] - 7
[[SoundCircle]] - 8.5
[[VGAP]] - 4.5
[[Medibolt-Akhilesh4444]] - 4.5
[[FreelanceHub]] - 5
[[Codeswipe-Suhas]] - 5.5
[[Crescendo]] - 6.5
[[Bit-Builder]] - 5.5
[[Sentiment-Analyser-using-DistilBERT]] - 6





