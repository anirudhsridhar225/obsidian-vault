## Team Members:
1. Hardik Singh
2. Karman Singh
3. fatchubbyman (github id)
## Remarks:
- good demo video
- python based recommendation system
- discord.js bot (good)
- good code mostly
## Score:
8/10 rates pretty high for me