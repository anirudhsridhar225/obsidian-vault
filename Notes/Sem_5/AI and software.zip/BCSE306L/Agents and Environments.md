
# Agents

- entities that take the system from initial to goal state
- they "act rationally"
- can become independent of prior

# PEAS
1. Performance
2. Environment
3. Actuators
4. Sensors

# Types of agents

1. Simple reflex
2. Model based reflex
3. Goal based
4. Utility based
5. Learning agents