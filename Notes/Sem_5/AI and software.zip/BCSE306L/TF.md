- defined as the ratio of a word's occurrence in a document to the total number of words in a document
- local variable used in term weighting
- frequency of a word(w) in a document(d)

$TF(w, d) = {\Sigma}w_{i}(w_{i} = w)/{\Sigma}w_i$
