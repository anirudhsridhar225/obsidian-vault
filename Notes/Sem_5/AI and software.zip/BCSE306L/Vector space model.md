works on an assumption: documents that are "close together" in the vector space will be retrieved. hence. documents retrieved based on similarity

difference from boolean model: term weights are no longer 0 or 1.
each term weight is computed based on variations of [[TF]] or [[TF-IDF]] scheme.

each document and vector are represented by vectors

$d_j = (w_{1_j},w_{2_j},....,w_{t_j})$
$q = (w_{1_q}, w_{2_q},....,w_{t_q})$

![[{31F32543-E310-407E-A7BA-728249FF2E77}.png]]
![[{C26A30E3-299E-4C56-902D-BA6A3CA81DBF}.png]]
![[{3BA23FB1-97EC-4F27-962C-BEF3DBB4DDE3}.png]]
