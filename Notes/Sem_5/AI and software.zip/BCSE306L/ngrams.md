model that assigns probabilities to sentences and word sequences

an n-gram is a sequence of n word:
1. an 1-gram is words like "please", etc. basically 0 word history
2. a 2-gram is "please turn", basically 1 word history

similar, n-gram = n word sequence, n-1 word history