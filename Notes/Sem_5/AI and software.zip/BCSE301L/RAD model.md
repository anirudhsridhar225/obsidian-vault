![[RAD model.excalidraw | 1900]]

uses:
1. short span time (2-3 months)
2. requirements are well-known
3. technical risk is limited
4. used only if budget allows the use of automatic code generating tools

