# Process measurement
- measure the efficacy of a software process indirectly
- derive a set of metrics based on the outcomes that can be derived from the process
- outcomes include:
	1. measure of errors uncovered before release
	2. defects
	3. work products delivered
	4. human effort expended
	5. calender time expended
	6. schedule conformed

