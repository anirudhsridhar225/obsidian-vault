Formulae:

1. Cost
	 $C$ = $a*(L)^b$
	 where,
		 C = cost
		 a, b = constants
		 L = size
2. Effort
	 $E$ = $1.4*(L)^{0.93}$ person-months
3. Documentation
	 $DOC$ = $30.4*(L)^{0.90}$
4. Duration
	 $D$ = $4.6*(L)^{0.26}$

