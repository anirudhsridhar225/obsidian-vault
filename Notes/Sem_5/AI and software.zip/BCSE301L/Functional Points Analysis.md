
| Information Domain Value       | Simple | Average | Complex |
| ------------------------------ | ------ | ------- | ------- |
| External Inputs (EI)           | 3      | 4       | 6       |
| External Outputs (EO)          | 4      | 5       | 7       |
| External Inquiries (EQ)        | 3      | 4       | 6       |
| Internal Logical Files (ILF)   | 7      | 10      | 15      |
| External Interface Files (EIF) | 5      | 7       | 10      |
for each val, compute $c_i$ = $count*val$

$FP$ = $count_{total}*[0.65 + 0.01*\Sigma(F_i)]$
