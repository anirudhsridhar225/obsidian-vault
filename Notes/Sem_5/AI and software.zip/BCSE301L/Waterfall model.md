
![[Waterfall Model.excalidraw | 20000]]

Uses:
1. when req are constant
2. project is short
3. tools and tech used are consistent
4. resources are well prepared