![[Iterative Model.excalidraw | 2000]]

uses:
1. requirements are clearly defined
2. requirement of changes in future
3. app is large
4. new tech is being used